HOW TO PUT THIS ONLINE (Render, free)
1. Upload all these files to a new GitHub repository.
2. On render.com: New > Web Service > pick the repository.
3. Build command: npm install   Start command: npm start
4. Click Create. Open the .onrender.com link and share it.
Do NOT use Netlify: it cannot run the game server.
Test locally: npm install && npm start, then open http://localhost:3000
