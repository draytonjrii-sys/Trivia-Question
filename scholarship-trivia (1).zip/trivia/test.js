const WebSocket=require('ws');const {spawn}=require('child_process');
const srv=spawn('node',['server.js'],{env:{...process.env,PORT:3111,QMS:1500,RMS:300},stdio:'inherit'});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function client(name){return new Promise(res=>{const ws=new WebSocket('ws://localhost:3111');const c={ws,name,pid:name+Math.random(),s:null,errs:[],seen:[]};
 ws.on('message',d=>{const m=JSON.parse(d);if(m.type==='error')c.errs.push(m.msg);else{c.s=m;if(m.phase==='question'&&!c.seen.includes(m.q.text))c.seen.push(m.q.text)}});
 ws.on('open',()=>res(c))})}
const send=(c,o)=>c.ws.send(JSON.stringify(o));
const ok=(cond,msg)=>{console.log(cond?'PASS':'FAIL',msg);if(!cond)process.exitCode=1};
(async()=>{await sleep(500);
 const [a,b,c,d]=await Promise.all(['Ann','Bob','Cy','Late'].map(client));
 send(a,{type:'join',code:'ZZZZ',name:'Ann',pid:a.pid});await sleep(150);ok(a.errs[0]==='Room not found. Check your code.','invalid code -> error, no room');
 send(a,{type:'create',name:'Ann',pid:a.pid});await sleep(150);const code=a.s.code;ok(/^[A-Z]{4}$/.test(code),'4-letter code '+code);
 send(b,{type:'join',code,name:'Bob',pid:b.pid});send(c,{type:'join',code:code.toLowerCase(),name:'Cy',pid:c.pid});await sleep(200);
 ok(a.s.players.length===3&&b.s.host===a.pid,'3 players visible, host=Ann');
 send(b,{type:'start'});await sleep(100);ok(a.s.phase==='lobby','non-host cannot start');
 send(a,{type:'start'});await sleep(200);ok([a,b,c].every(x=>x.s.phase==='question'&&x.s.q.text===a.s.q.text),'all see same question');
 ok(a.s.correct===null,'answer not leaked during question');
 send(d,{type:'join',code,name:'Late',pid:d.pid});await sleep(150);ok(d.s.spec===true,'late joiner is spectator');
 let n=0,bobDropped=false;
 for(;;){await sleep(100);
  if(a.s.phase==='final')break;
  if(a.s.phase==='question'){ for(const x of [a,b,c]){ if(x.s.choice===null&&x.ws.readyState===1){send(x,{type:'answer',choice:x===a?0:1});send(x,{type:'answer',choice:2});} } }
  if(a.s.idx===3&&!bobDropped){bobDropped=true;b.ws.close();}
  if(++n>400)break}
 ok(a.s.phase==='final','reached final after 10 questions (Bob disconnected mid-game)');
 ok(a.seen.length===10&&new Set(a.seen).size===10,'10 distinct questions');
 ok(a.s.players.every(p=>p.score>=0)&&a.s.players.find(p=>p.id===d.pid).score===0,'spectator scored 0');
 ok(a.s.players.find(p=>p.id===a.pid).score%1===0,'scores: Ann '+a.s.players.map(p=>p.name+':'+p.score).join(' '));
 send(a,{type:'again'});await sleep(150);ok(a.s.phase==='lobby'&&c.s.phase==='lobby','play again returns to lobby');
 a.ws.close();await sleep(200);ok(c.s.host===c.pid,'host transferred when host disconnects');
 srv.kill();process.exit()})();
