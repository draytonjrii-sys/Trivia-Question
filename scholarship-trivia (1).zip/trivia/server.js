const http=require('http'),fs=require('fs'),path=require('path'),{WebSocketServer}=require('ws');
const BANK=require('./questions');
const QMS=+process.env.QMS||15000, RMS=+process.env.RMS||5000, NQ=10;
const rooms=new Map();
const shuffle=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const html=fs.readFileSync(path.join(__dirname,'public/index.html'));
const server=http.createServer((req,res)=>{
  if(req.url==='/health'){res.end('ok');return}
  res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(html)});
const wss=new WebSocketServer({server});
function code(){const L='ABCDEFGHJKLMNPQRSTUVWXYZ';let c;do{c=Array.from({length:4},()=>L[Math.floor(Math.random()*L.length)]).join('')}while(rooms.has(c));return c}
const active=r=>[...r.players.values()].filter(p=>p.on&&!p.spec);
function pickHost(r){const h=r.players.get(r.host);if(h&&h.on)return;const n=[...r.players.values()].find(p=>p.on);if(n)r.host=n.id}
function push(r){
  const list=[...r.players.values()].map(p=>({id:p.id,name:p.name,score:p.score,on:p.on,spec:p.spec,done:r.answers.has(p.id)}));
  for(const p of r.players.values()){ if(!p.on||p.ws.readyState!==1)continue;
    const q=r.qs[r.idx],a=r.answers.get(p.id),rev=r.phase==='reveal';
    p.ws.send(JSON.stringify({type:'state',phase:r.phase,code:r.code,host:r.host,you:p.id,spec:p.spec,players:list,
      idx:r.idx,total:NQ,now:Date.now(),endsAt:r.endsAt,qms:QMS,
      q:q&&r.phase!=='lobby'&&r.phase!=='final'?{cat:q.cat,text:q.text,opts:q.opts}:null,
      choice:a?a.choice:null,pts:rev&&a?a.pts:0,correct:rev?q.ans:null}))}}
function ask(r){
  r.phase='question';r.endsAt=Date.now()+QMS;r.answers=new Map();push(r);
  clearTimeout(r.t);r.t=setTimeout(()=>reveal(r),QMS+250)}
function reveal(r){
  if(r.phase!=='question')return;clearTimeout(r.t);r.phase='reveal';
  const q=r.qs[r.idx];
  for(const [id,a] of r.answers){const p=r.players.get(id);a.pts=a.choice===q.ans?Math.round(500+500*(1-a.ms/QMS)):0;if(p)p.score+=a.pts}
  r.endsAt=Date.now()+RMS;push(r);
  r.t=setTimeout(()=>{if(++r.idx>=NQ){r.phase='final';r.endsAt=0;push(r)}else ask(r)},RMS)}
function start(r){
  const fresh=BANK.filter((_,i)=>!r.used.has(i)); const pool=fresh.length>=NQ?fresh:BANK; if(pool===BANK)r.used.clear();
  r.qs=shuffle(pool).slice(0,NQ).map(b=>{const opts=shuffle(b.slice(2));r.used.add(BANK.indexOf(b));return{cat:b[0],text:b[1],opts,ans:opts.indexOf(b[2])}});
  for(const p of r.players.values()){p.score=0;p.spec=!p.on}
  r.idx=0;ask(r)}
wss.on('connection',ws=>{
  let room=null,me=null;
  const err=m=>ws.send(JSON.stringify({type:'error',msg:m}));
  const clean=s=>String(s||'').replace(/[^\p{L}\p{N} _.-]/gu,'').trim().slice(0,16);
  function enter(r,pid,name){
    let p=r.players.get(pid);
    if(p){p.on=true;if(p.ws&&p.ws!==ws)try{p.ws.close()}catch{}p.ws=ws;if(name)p.name=name}
    else{p={id:pid,name,score:0,on:true,ws,spec:r.phase!=='lobby'};r.players.set(pid,p)}
    room=r;me=p;clearTimeout(r.gc);pickHost(r);push(r)}
  ws.on('message',raw=>{let m;try{m=JSON.parse(raw)}catch{return}
    if(m.type==='create'){const name=clean(m.name);if(!name)return err('Enter your name first.');
      const r={code:code(),host:m.pid,players:new Map(),phase:'lobby',qs:[],idx:0,answers:new Map(),used:new Set(),endsAt:0};
      rooms.set(r.code,r);enter(r,m.pid,name);return}
    if(m.type==='join'){const r=rooms.get(String(m.code||'').toUpperCase().trim());
      if(!r)return err('Room not found. Check your code.');
      const name=clean(m.name);if(!name&&!r.players.has(m.pid))return err('Enter your name first.');
      if(!r.players.has(m.pid)&&[...r.players.values()].some(p=>p.on&&p.name.toLowerCase()===name.toLowerCase()))return err('That name is taken in this room.');
      enter(r,m.pid,name);return}
    if(!room||!me)return;
    if(m.type==='start'&&room.host===me.id&&room.phase==='lobby'||m.type==='again'&&room.host===me.id&&room.phase==='final'){
      if(m.type==='again'){room.phase='lobby';for(const p of room.players.values())p.spec=false;push(room)}else if(active(room).length>=1)start(room);return}
    if(m.type==='answer'&&room.phase==='question'&&!me.spec&&!room.answers.has(me.id)&&Number.isInteger(m.choice)&&m.choice>=0&&m.choice<4){
      const ms=Math.min(QMS,Math.max(0,Date.now()-(room.endsAt-QMS)));
      room.answers.set(me.id,{choice:m.choice,ms,pts:0});
      if(active(room).every(p=>room.answers.has(p.id)))reveal(room);else push(room);return}
    if(m.type==='leave')drop(true)});
  function drop(leave){ if(!room||!me)return; const r=room;
    if(leave){r.players.delete(me.id)}else{me.on=false}
    room=null;pickHost(r);
    if(![...r.players.values()].some(p=>p.on)){r.gc=setTimeout(()=>{clearTimeout(r.t);rooms.delete(r.code)},60000)}
    else{ if(r.phase==='question'&&active(r).length&&active(r).every(p=>r.answers.has(p.id)))reveal(r);else push(r)}
    me=null}
  ws.on('close',()=>drop(false));
});
server.listen(process.env.PORT||3000,()=>console.log('Listening on',process.env.PORT||3000));
